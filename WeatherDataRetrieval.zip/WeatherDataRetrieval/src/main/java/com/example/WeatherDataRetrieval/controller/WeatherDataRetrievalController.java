package com.example.WeatherDataRetrieval.controller;

import com.example.WeatherDataRetrieval.service.WeatherDataRetrievalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/weather")
public class WeatherDataRetrievalController {
    private final WeatherDataRetrievalService weatherDataRetrievalService;

    @Autowired
    public WeatherDataRetrievalController(WeatherDataRetrievalService weatherDataRetrievalService) {
        this.weatherDataRetrievalService = weatherDataRetrievalService;
    }

    @GetMapping("/{locationId}")
    public String getWeatherData(
            @PathVariable String locationId,
            @RequestParam(required = false) String date
    ) {
        if (date != null) {
            // Handle weather data retrieval by location and date
            // Replace this with your actual logic for fetching weather data for a specific date and location
            return "Weather data for location " + locationId + " on date " + date;
        } else {
            // Handle weather data retrieval by location only
            // Replace this with your logic for fetching weather data by location only
            return "Weather data for location " + locationId;
        }
    }
}
