package com.example.WeatherForecastService.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Document(collection = "historical_weather")
public class HistoricalWeather {
    @Id
    private String id;

    private LocalDate date;
    private String location;
    private String weather;
    private double temperature;

    public HistoricalWeather() {
    }

    public HistoricalWeather(LocalDate date, String location, String weather, double temperature) {
        this.date = date;
        this.location = location;
        this.weather = weather;
        this.temperature = temperature;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getWeather() {
        return weather;
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
}
