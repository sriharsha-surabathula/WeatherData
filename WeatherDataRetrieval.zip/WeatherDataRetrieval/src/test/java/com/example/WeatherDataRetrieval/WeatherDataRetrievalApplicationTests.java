package com.example.WeatherDataRetrieval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherDataRetrievalApplicationTests {

	@Test
	void contextLoads() {
	}

}
