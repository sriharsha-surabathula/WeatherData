package com.example.WeatherForecastService.repository;

import com.example.WeatherForecastService.entity.HistoricalWeather;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface HistoricalWeatherRepository extends MongoRepository<HistoricalWeather, String> {
    List<HistoricalWeather> findByLocationAndDate(String location, LocalDate date);
}
