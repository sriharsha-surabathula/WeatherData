package com.example.WeatherForecastService.service;

import com.example.WeatherForecastService.entity.HistoricalWeather;
import com.example.WeatherForecastService.repository.HistoricalWeatherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class HistoricalWeatherService {
    private final HistoricalWeatherRepository repository;

    @Autowired
    public HistoricalWeatherService(HistoricalWeatherRepository repository) {
        this.repository = repository;
    }

    public void saveHistoricalWeather(HistoricalWeather weatherData) {
        repository.save(weatherData);
    }

    public List<HistoricalWeather> getWeatherByLocationAndDate(String location, LocalDate date) {
        return repository.findByLocationAndDate(location, date);
    }

    public List<HistoricalWeather> getAllWeatherData() {
        return repository.findAll();
    }

    public ResponseEntity<String> updateHistoricalWeather(Long id, HistoricalWeather weatherData) {
        Optional<HistoricalWeather> existingWeatherData = repository.findById(String.valueOf(id));
        if (existingWeatherData.isPresent()) {
            weatherData.setId(String.valueOf(id));
            repository.save(weatherData);
            return ResponseEntity.ok("Historical weather data updated successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    public ResponseEntity<String> deleteHistoricalWeather(Long id) {
        if (repository.existsById(String.valueOf(id))) {
            repository.deleteById(String.valueOf(id));
            return ResponseEntity.ok("Historical weather data deleted successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
