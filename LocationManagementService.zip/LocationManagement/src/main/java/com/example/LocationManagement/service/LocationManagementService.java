package com.example.LocationManagement.service;

import com.example.LocationManagement.entity.LocationEntity;
import java.util.List;

public interface LocationManagementService {
    List<LocationEntity> getAllLocations();
    LocationEntity getLocationById(String id);
    String addLocation(LocationEntity location);
    boolean updateLocation(String id, LocationEntity location);
    boolean deleteLocation(String id);
}
